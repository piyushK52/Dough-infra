from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
import json
import uuid
import requests
from io import BytesIO
import io
import zipfile
import mimetypes
import os
import boto3
from PIL import Image

AWS_S3_BUCKET = "banodoco-temp-data-bucket-public"
AWS_S3_REGION = 'ap-south-1'
s3_client = boto3.client(
    service_name='s3',
    region_name="ap-south-1"
)

# for generating zip
def generate_zip(event, context):
    print("event: ", event)
    event = json.loads(event["body"])
    img_list = event["img_list"]
    if 'width' in event:
        width = event['width']
        height = event['height']
    else:
        width, height = None, None

    zip_buffer = download_and_create_zip_buffer(img_list, width, height)
    object_url = upload_file(file=zip_buffer.getvalue(), file_name=f'images_{str(uuid.uuid4())}.zip', expire_in= 60 * 60 * 24)
    
    print("uploading obj: ", object_url)
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "zip_url": object_url
        })
    }
    
    return response

def download_and_process_image(url, width, height):
    response = requests.get(url)
    file_buffer = io.BytesIO(response.content)
    file = Image.open(file_buffer)
    processed_file = zoom_and_crop(file, width, height)
    img_bytes = io.BytesIO()
    processed_file.save(img_bytes, format="PNG")
    return img_bytes.getvalue()

def download_and_create_zip_buffer(urls, width, height):
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "a", zipfile.ZIP_DEFLATED, False) as zip_file:
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_url = {executor.submit(download_and_process_image, url, width, height): url for url in urls}
            for i, future in enumerate(concurrent.futures.as_completed(future_to_url)):
                url = future_to_url[future]
                try:
                    img_bytes = future.result()
                except Exception as exc:
                    print(f'Error processing {url}: {exc}')
                else:
                    zip_file.writestr(f"image{i+1}.png", img_bytes)
    zip_buffer.seek(0)
    return zip_buffer

def zoom_and_crop(file, width, height):
    if not width or (file.width == width and file.height == height):
        return file

    # Scaling
    s_x = width / file.width
    s_y = height / file.height
    scale = max(s_x, s_y)
    new_width = int(file.width * scale)
    new_height = int(file.height * scale)
    file = file.resize((new_width, new_height))

    # Cropping
    left = (file.width - width) // 2
    top = (file.height - height) // 2
    right = (file.width + width) // 2
    bottom = (file.height + height) // 2
    file = file.crop((left, top, right, bottom))

    return file

def upload_file(
    file,
    file_name="default",
    bucket=AWS_S3_BUCKET,
    object_name=None,
    folder="posts/",
    expire_in=60*60,  # file will be deleted after these many seconds
):
    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    unique_tag = str(uuid.uuid4())
    file_extension = os.path.splitext(object_name)[1]
    filename = unique_tag + file_extension

    # Upload the file
    content_type = mimetypes.guess_type(object_name)[0]
    data = {
        "Body": file,
        "Bucket": bucket,
        "Key": folder + filename,
        "ACL": "public-read",
    }

    if expire_in:
        data["Metadata"] = {
            "expire_in": str(expire_in)
        }  # don't change this key, cron-job uses this

    if content_type:
        data["ContentType"] = content_type

    resp = s3_client.put_object(**data)
    object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
        AWS_S3_REGION, AWS_S3_BUCKET, folder + filename
    )
    return object_url