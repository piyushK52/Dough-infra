import json
import uuid
import requests
from io import BytesIO
import zipfile
import mimetypes
import os
import boto3
from PIL import Image

AWS_S3_BUCKET = "banodoco-temp-data-bucket-public"
AWS_S3_REGION = 'ap-south-1'
s3_client = boto3.client(
    service_name='s3',
    region_name="ap-south-1"
)

# for generating collage
def generate_collage(event, context):
    print("event: ", event)
    event = json.loads(event["body"])
    user_input_images_url = event['user_input_images_url']
    response = requests.get(user_input_images_url)
    zip_content = response.content
    zip_file = BytesIO(zip_content)
    images, extract_dir = extract_images_from_zip(zip_file)
    collage = arrange_images_on_sheet(images, images_per_column=2)
    
    object_url = upload_file(
        file=collage,
        file_name=str(uuid.uuid4()) + ".png",
    )
    
    print("uploading obj: ", object_url)
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "collage_url": object_url
        })
    }
    
    return response

def extract_images_from_zip(zip_path):
    images = []
    extract_dir = f"/tmp/extracted_images_{uuid.uuid4()}"
    
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        os.makedirs(extract_dir, exist_ok=True)
        zip_ref.extractall(extract_dir)
        
        image_files = [
            file for file in os.listdir(extract_dir)
            if file.lower().endswith((".png", ".jpg", ".jpeg"))
        ]
        
        images = [Image.open(os.path.join(extract_dir, file)) for file in image_files]
    
    return images, extract_dir

def arrange_images_on_sheet(images, images_per_column=2):
    max_size_mb = 20
    images = sorted(images, key=lambda img: img.filename)

    max_img_width = max(image.width for image in images)
    max_img_height = max(image.height for image in images)

    if len(images) > 6 and len(images) < 10:
        images_per_column = 4
    elif len(images) >= 10:
        images_per_column = 5
    max_sheet_width = 1024

    total_columns = images_per_column
    total_rows = (len(images) + images_per_column - 1) // images_per_column

    sheet_width = min(max_img_width * total_columns, max_sheet_width)
    
    w = int(sheet_width / total_columns)
    r = w / max_img_width
    max_img_width = int(max_img_width*r)
    max_img_height = int(max_img_height*r)

    sheet_width = min(max_img_width * total_columns, max_sheet_width)
    sheet_height = int(max_img_height * total_rows)
    sheet = Image.new("RGB", (sheet_width, sheet_height), color="white")

    for index, image in enumerate(images):
        ratio = max_img_width / image.width
        # height_ratio = sheet_height / image.height
        # ratio = min(width_ratio, height_ratio)

        new_width = int(image.width * ratio)
        new_height = int(image.height * ratio)

        resized_image = image.resize((new_width, new_height), resample=Image.Resampling.BICUBIC)

        column = index % total_columns
        row = index // total_columns

        x_offset = (max_img_width - new_width) // 2
        y_offset = (max_img_height - new_height) // 2

        sheet.paste(resized_image, (max_img_width * column + x_offset, max_img_height * row + y_offset))

    quality = 95
    while True:
        image_io = BytesIO()
        sheet.save(image_io, format='JPEG', quality=quality)
        image_size_mb = image_io.getbuffer().nbytes / (1024 * 1024)

        if image_size_mb <= max_size_mb:
            break

        quality -= 5
        if quality < 50:
            scale_factor = 0.9
            sheet_width = int(sheet_width * scale_factor)
            sheet_height = int(sheet_height * scale_factor)
            sheet = sheet.resize((sheet_width, sheet_height), resample=Image.Resampling.BICUBIC)

    image_io.seek(0)
    return image_io

def upload_file(
    file,
    file_name="default",
    bucket=AWS_S3_BUCKET,
    object_name=None,
    folder="posts/",
    expire_in=60*60,  # file will be deleted after these many seconds
):
    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    unique_tag = str(uuid.uuid4())
    file_extension = os.path.splitext(object_name)[1]
    filename = unique_tag + file_extension

    # Upload the file
    content_type = mimetypes.guess_type(object_name)[0]
    data = {
        "Body": file,
        "Bucket": bucket,
        "Key": folder + filename,
        "ACL": "public-read",
    }

    if expire_in:
        data["Metadata"] = {
            "expire_in": str(expire_in)
        }  # don't change this key, cron-job uses this

    if content_type:
        data["ContentType"] = content_type

    resp = s3_client.put_object(**data)
    object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
        AWS_S3_REGION, AWS_S3_BUCKET, folder + filename
    )
    return object_url