from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
import os
import json
import requests
import mimetypes
import uuid
import boto3

AWS_S3_BUCKET = "banodoco-temp-data-bucket-public"
AWS_S3_REGION = 'ap-south-1'
s3_client = boto3.client(
    service_name='s3',
    region_name="ap-south-1"
)

'''
image_data_list = [
    {
        "file_name": "abc.png",
        "url": "xyz.com",
        "expire_in": 60*60
    }
]
'''
def refresh_url(event, context):
    print("event: ", event)
    event =  json.loads(event["body"])
    img_data_list = event["image_data_list"]
    
    if not (img_data_list and len(img_data_list)):
        return
    
    res = {}
    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_url = {executor.submit(download_or_update_file_url, **img_data): img_data["url"] for img_data in img_data_list}
        for future in concurrent.futures.as_completed(future_to_url):
            url = future_to_url[future]
            try:
                img_url = future.result()
                res[url] = img_url
            except Exception as exc:
                print(f'Error processing {url}: {exc}')
                
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "res": res
        })
    }
    
    return response

    
def download_or_update_file_url(url, file_name, expire_in):
    new_url = None
    try:
        # uploading if it's not a s3 url, else just udpating the expire_in time
        if not "banodoco" in url:
            response = requests.get(url)
            file_content = response.content
            print("file content: ", file_content)
            if (file_content and "no longer available" in file_content) or not file_content:
                return None
            new_url = upload_file(file_content, file_name, expire_in=expire_in)
        else:
            update_url_expiry(url, expire_in=expire_in)
            new_url = url
    except Exception as e:
        pass
    return new_url


def update_url_expiry(s3_url, new_expire_in_seconds):
    bucket_name, key = extract_bucket_and_key(s3_url)
    s3_client.copy_object(
        Bucket=bucket_name,
        Key=key,
        CopySource={'Bucket': bucket_name, 'Key': key},
        Metadata={'expire_in': str(new_expire_in_seconds)},
        MetadataDirective='REPLACE'
    )

def extract_bucket_and_key(s3_url):
    parts = s3_url.replace('https://s3-', '').split('.')
    region = parts[0]
    bucket_name = parts[1]
    key = '/'.join(parts[2:])
    return bucket_name, key

def upload_file(
    file,
    file_name="default",
    bucket=AWS_S3_BUCKET,
    object_name=None,
    folder="posts/",
    expire_in=60*60,  # file will be deleted after these many seconds
):
    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    unique_tag = str(uuid.uuid4())
    file_extension = os.path.splitext(object_name)[1]
    filename = unique_tag + file_extension

    # Upload the file
    content_type = mimetypes.guess_type(object_name)[0]
    data = {
        "Body": file,
        "Bucket": bucket,
        "Key": folder + filename,
        "ACL": "public-read",
    }

    if expire_in:
        data["Metadata"] = {
            "expire_in": str(expire_in)
        }  # don't change this key, cron-job uses this

    if content_type:
        data["ContentType"] = content_type

    resp = s3_client.put_object(**data)
    object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
        AWS_S3_REGION, AWS_S3_BUCKET, folder + filename
    )
    return object_url